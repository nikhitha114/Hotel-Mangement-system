REQUIREMENTS:
1. Download & Install: XAMPP in C:\xampp (default)
2. Clone this repository in C:\xampp\htdocs
3. Run XAMPP and start "Apache" and "MySQL"
4. Open the link "localhost/phpmyadmin/"
5. Click on new at sidebar and create a database name "hotelbookingmanagement"
6. After clicking database click import and select the file "hotelbookingmanagement.sql"
4. Open the link "localhost/HotelBookingManagement/"
8. Now register and login

Admin Credentials: admin, admin@123

config.php - Configure Database

register.php - Allows user to create an account

login.php - Allows user to Login

logout.php - Allows user to logout

accountInfo.php - The user can check his account info and all his reservations

forgotPassword.php - Reset account password

contactt.php - Contact form for logged in users

home.php - User can choose check in date, and rooms for reservations

payment.php - Payment page for reservations

rooms.php - Admin can modify room prices or add Discounted Price

dashboard.php - Admin can check all the reservations made by users, contactform responses, and list of all admins and clients

update.php - Update details like checked-in, replied to contactform response, make/remove admin

delete.php - Cancel bookings
